import React from "react";

// Import Icons
import { GoTasklist } from 'react-icons/go';

class HomeProjectList extends React.Component {

    render(){
        return (
        
            <div className="d-flex justify-content-center home-project-list block-dark mt-2 px-1 pt-3">
            <div className="d-flex flex-column justify-content-start">
                <h1 className="mb-4 mt-2 text-center">Susceptible de vous intéresser</h1>


            <div className="block-home-list custom_scrollbar">

                {/* Single List Result */}
                <div className="single-list-result block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>

                {/* Single List Result */}
                <div className="single-list-result  block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>

                {/* Single List Result */}
                <div className="single-list-result  block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>

                {/* Single List Result */}
                <div className="single-list-result  block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>
                {/* Single List Result */}
                <div className="single-list-result  block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>
                {/* Single List Result */}
                <div className="single-list-result  block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>
                {/* Single List Result */}
                <div className="single-list-result  block-dark-hover pointer py-4 px-4">
                <div className="row mx-0">
                    <div className="d-flex justify-content-center col-2">
                        <GoTasklist />
                    </div>
                    <div className="d-flex justify-content-center col-10">
                    <h4>Titre du super Projet !</h4>
                    </div>
                    
                </div>
                <div className="row mx-0 text-center">
                <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad similique, rem, illum pariatur exercitationem vel omnis hic amet nisi iusto.
                    </p>
                    </div>
                    </div>




                    </div>
            </div>
        </div>

        )
    }

}

export default HomeProjectList;